//Select2
$.getScript('http://cdnjs.cloudflare.com/ajax/libs/select2/3.4.8/select2.min.js',function(){
           

  
  /* Select2 plugin as tagpicker */
  $("#userPicker").select2({
    closeOnSelect:false
  });
  
  $("#driverPicker").select2({
    closeOnSelect:false 
  });
  
  $("#adddriverPicker").select2({
    closeOnSelect:false 
  });
  
  $("#vehiclePicker").select2({
    closeOnSelect:false 
  });
  
  $("#addvehiclePicker").select2({
    closeOnSelect:false 
  });

}); //script  

  /* Select2 plugin as tagpicker */
  $("#mastersPicker").select2({
    closeOnSelect:true
  });

 //script    
 
   /* Select2 plugin as tagpicker */
  $("#hosPicker").select2({
    closeOnSelect:true
  });

 //script 
 
    /* Select2 plugin as tagpicker */
  $("#virPicker").select2({
    closeOnSelect:true
  });

 //script
 
     /* Select2 plugin as tagpicker */
  $("#ttPicker").select2({
    closeOnSelect:true
  });

 //script  
 
      /* Select2 plugin as tagpicker */
  $("#reportsPicker").select2({
    closeOnSelect:true
  });

 //script  
 
 /*--adding--*/
 
 
 
 
      

$(document).ready(function() {});

