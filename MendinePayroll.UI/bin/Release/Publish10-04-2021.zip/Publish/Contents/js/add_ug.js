//Select2
$.getScript('http://cdnjs.cloudflare.com/ajax/libs/select2/3.4.8/select2.min.js',function(){
           

  
  /* Select2 plugin as tagpicker */
  $("#userPicker-b").select2({
    closeOnSelect:false
  });

}); //script  

  /* Select2 plugin as tagpicker */
  $("#mastersPicker-b").select2({
    closeOnSelect:true
  });

 //script    
 
   /* Select2 plugin as tagpicker */
  $("#hosPicker-b").select2({
    closeOnSelect:true
  });

 //script 
 
    /* Select2 plugin as tagpicker */
  $("#virPicker-b").select2({
    closeOnSelect:true
  });

 //script
 
     /* Select2 plugin as tagpicker */
  $("#ttPicker-b").select2({
    closeOnSelect:true
  });

 //script  
 
      /* Select2 plugin as tagpicker */
  $("#reportsPicker-b").select2({
    closeOnSelect:true
  });

 //script  
 
 /*--adding--*/
 
 
 
 
      

$(document).ready(function() {});

