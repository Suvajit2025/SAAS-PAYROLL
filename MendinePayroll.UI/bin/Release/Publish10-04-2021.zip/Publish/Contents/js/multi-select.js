/*!
 * 
 */
$.components.register("multiSelect", {
  mode: "default",
  defaults: {}
});
